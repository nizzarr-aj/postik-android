POSTIK Android - Icon Fix

This package keeps the existing POSTIK WebView app and adds the POSTIK launcher icon.
It also bumps the Android version to 1.1.

Replace the Android project files in the postik-android repository with these files,
then run the Build POSTIK Android APK GitHub Action.
The generated artifact is app-debug.apk.
