POSTIK Android 1.2 - FINAL LOGO
The launcher icon is the POSTIK P + TikTok-inspired growth logo.
Build with GitHub Actions -> Build POSTIK Android APK.
