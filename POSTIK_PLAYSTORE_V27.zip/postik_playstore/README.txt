POSTIK — Google Play preparation V27

This package prepares the current POSTIK Android wrapper for Google Play:
- compileSdk 36
- targetSdk 36
- versionCode 7
- versionName 1.6
- WebView points to POSTIK website cache-bust v26
- Release AAB workflow included

IMPORTANT:
Do NOT put a .jks/keystore or passwords inside the public GitHub repository.
The build workflow expects these GitHub Actions secrets:
1) POSTIK_UPLOAD_KEYSTORE_BASE64
2) POSTIK_KEYSTORE_PASSWORD
3) POSTIK_KEY_ALIAS
4) POSTIK_KEY_PASSWORD

Google Play uses an upload key to sign the AAB you upload, while Google manages the app signing key for the delivered APKs when Play App Signing is enabled.

HOW TO APPLY:
1. Upload POSTIK_PLAYSTORE_V27.zip to the ROOT of nizzarr-aj/postik-android.
2. In GitHub, open Actions and run "Unpack POSTIK Play Store V27".
3. Add the four GitHub Actions secrets listed above.
4. Run "Build POSTIK Play Store AAB".
5. Download the artifact "POSTIK-PlayStore-AAB-v1.6".
6. Upload app-release.aab to Play Console.

If you do not yet have an upload keystore, create one securely (RSA 2048+), keep the .jks private, and register its certificate in Play Console as the upload key. Do not send the keystore or passwords in chat.

Current package name: com.postik.app
